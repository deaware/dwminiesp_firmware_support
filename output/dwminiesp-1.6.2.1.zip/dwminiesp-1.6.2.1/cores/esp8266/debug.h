#ifndef ARD_DEBUG_H
#define ARD_DEBUG_H

#include <stddef.h>
// #define DEBUGV(...) ets_printf(__VA_ARGS__)
#define DEBUGV(...) 

#endif//ARD_DEBUG_H
